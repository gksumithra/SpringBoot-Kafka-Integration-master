package com.application.kafkaspringbootdemo.service;

import com.application.kafkaspringbootdemo.model.PoDetails;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class AppListener {


    @KafkaListener(topics = "kafka-topic1",groupId = "my-springbootapp", containerFactory = "kafkaListenerContainerFactory")
    public void listenToKafkaTopic(PoDetails poDetails){
        System.out.println("Message received from Kafka topic is  ::::  ");
        System.out.println(poDetails);
    }

}

