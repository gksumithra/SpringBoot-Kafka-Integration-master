package com.application.springkafkaintegration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringKafkaIntegrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
