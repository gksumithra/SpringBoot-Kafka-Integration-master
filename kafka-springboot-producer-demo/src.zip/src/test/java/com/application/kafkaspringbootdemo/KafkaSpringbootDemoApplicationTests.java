package com.application.kafkaspringbootdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaSpringbootDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
